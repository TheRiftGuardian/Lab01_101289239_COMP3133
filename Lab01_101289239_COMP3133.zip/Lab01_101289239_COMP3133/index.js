var csv = require('csv-parser');
var fs = require('fs');

// Deleteing Text Files
try {
	fs.unlink('canada.txt', (err) => {
		if (err) {
			console.log(err);
			return;
		}
		console.log('canada.txt deleted successfully');
	});
} catch (err) {
	console.log('canada.txt not found');
}

try {
	fs.unlink('usa.txt', (err) => {
		if (err) {
			console.log(err);
			return;
		}
		console.log('usa.txt deleted successfully');
	});
} catch (err) {
	console.log('usa.txt not found');
}

// Adding header to text files
var header = 'country,year,population';
fs.writeFileSync('canada.txt', header + '\n');
fs.writeFileSync('usa.txt', header + '\n');
fs
	.createReadStream('input_countries.csv')
	.pipe(csv())
	.on('data', (row) => {
		// Filter data of Canada and write to text file
		if (row.country === 'Canada') {
			fs.appendFileSync('canada.txt', Object.values(row).join(',') + '\n');
		}
		// Filter data of USA and write to text file
		if (row.country === 'United States') {
			fs.appendFileSync('usa.txt', Object.values(row).join(',') + '\n');
		}
	})
	.on('end', () => {
		console.log('CSV File finished');
	});
